package com.gilgil2.locatingplaces.view;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.preference.PreferenceManager;
import android.util.Log;
import android.widget.Toast;

import com.gilgil2.locatingplaces.R;
import com.gilgil2.locatingplaces.model.PlacesAdapter;
import com.gilgil2.locatingplaces.model.PlacesContract;


public class SettingsActivity extends PreferenceActivity implements Preference.OnPreferenceClickListener, Preference.OnPreferenceChangeListener {

    private static final String TAG = "SettingsActivity";

    Preference prefdelete;
    ListPreference prefdist;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //this line reads the preferences XML and builds the screen for us:
        addPreferencesFromResource(R.xml.settings_xml);

        prefdelete = findPreference ("delete");
        prefdist = (ListPreference) findPreference("units");

        // SET CLICK LISTENERS
        // we'll set these on preferences we want to respond to clicks
        // (like <Preference> tags - no actual value is saved to the prefs file)
        prefdelete.setOnPreferenceClickListener(this);
        prefdist.setOnPreferenceChangeListener(this);

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);

        // set prefs screen summary
        //String unit = prefs.getString("units","km");
        //prefdist.getSummary(unit);

    }
    // --------------------------------------------------------------------------
    // -- preferences CHANGE
    @Override
    public boolean onPreferenceChange(Preference pref, Object newValue) {
        //get the key:
        String key = pref.getKey();
        Log.d(TAG, "clicked " + key);

        if (key.equals("units")){

        pref.setSummary((String) newValue);

    }  finish();
        return true;
    }
    // --------------------------------------------------------------------------
    // -- preferences CLICK

    @Override
    public boolean onPreferenceClick(Preference pref) {
        // a preference was clicked
        // pref - the preference

        //get the key:
        String key = pref.getKey();
        Log.d(TAG, "clicked " + key);

        //what pref was it? (key is a String : use if-else and not switch-case)
        if (key.equals("delete")){
            Toast.makeText(this, "no more favorites", Toast.LENGTH_SHORT).show();
            this.getContentResolver().delete(PlacesContract.Favorite.CONTENT_URI,null,null);
        }
        //handled.
        finish();
        return true;
    }


}
