package com.gilgil2.locatingplaces.view;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.gilgil2.locatingplaces.R;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMapOptions;
import com.google.android.gms.maps.SupportMapFragment;

public class FavoritsActivity extends AppCompatActivity {

    private static final String TAG = "FavoritsActivity";

    private PowerConnected powerConnected;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorits);

        // THE RECEIVER - create and register:
        // the intent filter will be the action -ACTION_POWER_CONNECTED
        powerConnected = new PowerConnected();
        IntentFilter filterpowerConnected = new IntentFilter (Intent.ACTION_POWER_CONNECTED);
        filterpowerConnected.addAction(Intent.ACTION_POWER_DISCONNECTED);
        registerReceiver(powerConnected, filterpowerConnected);

            // create the fragments:
            if (isOnePane()) {
                //single:

                //only add fragments if the state is null!
                //if there's a state - they will be re-attached automatically
                if (savedInstanceState == null) {
                    //create frag A
                    FragFavorits fragFavorits = FragFavorits.newInstance();

                    //get menager:
                    FragmentManager fm = getSupportFragmentManager();
                    // add it to the container:
                    FragmentTransaction ft = fm.beginTransaction();
                    ft.add(R.id.favContainer, fragFavorits, "Fav");
                    ft.commit();
                }

            } else {
                //dual:

                //only add fragments if the state is null!
                //if there's a state - they will be re-attached automatically
                if (savedInstanceState == null) {
                    //options for the created map fragment:
                    GoogleMapOptions options = new GoogleMapOptions();
                    // - map type
                    options.mapType(GoogleMap.MAP_TYPE_HYBRID);
                    // create map fragment with the options
                    Fragment fragMap = SupportMapFragment.newInstance(options);

                    FragFavorits fragFavorits = FragFavorits.newInstance();
                    //FragMap fragMap = new FragMap();

                    //get menager:
                    FragmentManager fm = getSupportFragmentManager();
                    // add them to the containers (A +B):
                    FragmentTransaction ft = fm.beginTransaction();
                    ft.add(R.id.favContainer, fragFavorits, "Fav");
                    //ft.add(R.id.fragmnetContainermap, fragMap, "Map");
                    ft.commit();
                }
            }
        }


        // ----------------------------------------------------------------------------
        // -- helper method: are we in a single fragment (like a phone) ?

    protected boolean isOnePane() {
        //try to find the layout with id : layout_singleLayout
        // this will be null on a dual fragment layout

        View layout_onePane = findViewById(R.id.layout_onePane);
        if (layout_onePane != null) {
            // found - we are
            return true;
        } else {
            // not found - we are not.
            return false;
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.favorites_options, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.action_home:
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                finish();
                return true;

            case R.id.action_settings2:
                // open the preferences activity
                Intent intent2 = new Intent(this, SettingsActivity.class);
                startActivity(intent2);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    // ----------------------------------------------------------------------------
    // -- RECEIVER CLASS - for broadcasts from powerconnected service
    class PowerConnected extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {

            if (intent.getAction().equals(Intent.ACTION_POWER_CONNECTED)) {
                Toast.makeText(context, "Power Connected", Toast.LENGTH_SHORT).show();
            } else if (intent.getAction().equals(Intent.ACTION_POWER_DISCONNECTED)) {
                Toast.makeText(context, "Power Disconnected", Toast.LENGTH_SHORT).show();
            }

        }
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(powerConnected);
    }
}
