package com.gilgil2.locatingplaces.util;

/**
 * Created by Gilly on 9/9/2015.
 */
public class Constants {

    private static final String API_KEY = "AIzaSyBAcCfiTw6-PxaHuqdmVkqChc7yb9OVRJw";

    private static final String SHA_ONE = "32:AF:42:67:69:DA:8B:9C:0B:98:7F:AD:A0:B8:FE:D1:CD:B4:9C:C0";

    private static final String MAP_KEY = "AIzaSyABdWejbtTSYheNirdy50WXMaydWxxWLUY";
}
