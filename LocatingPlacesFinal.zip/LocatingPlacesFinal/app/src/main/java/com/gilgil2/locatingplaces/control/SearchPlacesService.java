package com.gilgil2.locatingplaces.control;

/**
 * Created by Gilly on 9/9/2015.
 */

import android.app.IntentService;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;
import android.widget.Toast;

import com.gilgil2.locatingplaces.model.PlacesContract;
import com.gilgil2.locatingplaces.util.HttpHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

/**
 * a Service for searching a place and saving the results<br>
 * this will perform a search in the background and store the results in the
 * appProvider.<br>
 * (Previous results will be deleted!) <br>
 * <br>
 * start this service with the action: <b>{@code "com.gilgil2.locatingplaces.control.action.SEARCH"} </b><br>
 * <br>
 * expected extras:<br>
 * <ul>
 * 	<li>
 * 		<b>"query"</b> : the search String.
 * 	</li>
 * </ul>
 *
 * @author Yak
 *
 */
public class SearchPlacesService extends IntentService {

    // BROADCAST ACTIONS : these are the names of the broadcast-actions this service will send
    public static final String ACTION_INTERNET_CONNECTION = "com.gilgil2.locatingplaces.action.INTERNET_CONNECTION ";
    public static final String ACTION_RESULTS = "com.gilgil2.locatingplaces.action.RESULTS ";
    public static final String ACTION_SWIPE_REFRESH = "com.gilgil2.locatingplaces.action.SWIPE_REFRESH ";


    private static final String TAG = "SearchPlacesSevice";

    /**
     * the action to search nearby*
     */
    public static final String ACTION_NEAR_BY = "com.gilgil2.locatingplaces.action.NEAR_BY";


    /**
     * the action to search by text*
     */
    public static final String ACTION_SEARCH = "com.gilgil2.locatingplaces.action.SEARCH";

    /**
     * extra - the lat to search for*
     */
    public static final String EXTRA_LAT= "com.gilgil2.locatingplaces.extra.LAT";

    /**
     * extra - the lng to search for*
     */
    public static final String EXTRA_LNG= "com.gilgil2.locatingplaces.extra.LNG";

    /**
     * extra - the text to search for*
     */
    public static final String EXTRA_QUERY = "com.gilgil2.locatingplaces.extra.QUERY";

    // the radius to search from
    private final static int SEARCH_RADIUS = 5000;

    /**
     * the cloud project's API-URL for textsearch
     */
    private final static String SEARCH_API = "https://maps.googleapis.com/maps/api/place/textsearch/json";

    /**
     * the cloud project's API-URL for nearbysearch
     */
    private final static String SEARCH_APPI = "https://maps.googleapis.com/maps/api/place/nearbysearch/json";


    /**
     * the cloud project's API-KEY
     */
    private static final String API_KEY = "AIzaSyBAcCfiTw6-PxaHuqdmVkqChc7yb9OVRJw";

    public SearchPlacesService() {
        super("SearchPlacesService");
    }

    // ----------------------------------------------------------------------------
    @Override
    protected void onHandleIntent(Intent intent) {
        // checking internet connectivity before handling the intent
        ConnectivityManager cm = (ConnectivityManager)this.getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        boolean isConnected = activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();
        if (isConnected == false){
            //broadcast it:
            LocalBroadcastManager lbm = LocalBroadcastManager.getInstance(this);
            Intent broadcastIntent = new Intent(ACTION_INTERNET_CONNECTION);
            lbm.sendBroadcast(broadcastIntent);
        }else {

            if (intent != null) {
                String action = intent.getAction();

                if (ACTION_SEARCH.equals(action)) {
                    String query = intent.getStringExtra(EXTRA_QUERY);
                    handleSearch(query);

                } else if (ACTION_NEAR_BY.equals(action)) {
                    String query = intent.getStringExtra(EXTRA_QUERY);
                    double lat = intent.getDoubleExtra(EXTRA_LAT, 0);
                    double lng = intent.getDoubleExtra(EXTRA_LNG, 0);
                    handleNearBy(query, lat, lng);
                }
            }
        }
    }
// ----------------------------------------------------------------------------
    /**
     * handles the search action for this service
     *
     * @param query - the text to search for
     */
    private void handleSearch(String query) {

        //check if text is valid:
        if (query == null || query.length() < 2) {
            //don't search for queries less then 2 letters
            return;
        }

        // first - delete all data from the provider (places table):
        getContentResolver().delete(PlacesContract.Places.CONTENT_URI, null, null);

        // search:
        String queryString = null;
        try {
            queryString = ""
                    + "query=" + URLEncoder.encode(query, "utf-8")
                    + "&key=" + URLEncoder.encode(API_KEY, "utf-8");
        } catch (UnsupportedEncodingException e) {
        }
        String result = HttpHandler.get(SEARCH_API, queryString);
        Log.d(TAG, result);

        if (result == null){

            LocalBroadcastManager lbm = LocalBroadcastManager.getInstance(this);
            Intent broadcastIntent = new Intent(ACTION_RESULTS);
            lbm.sendBroadcast(broadcastIntent);

        }else {

            // parse the json response:
            try {

                //the response object:
                JSONObject jsonResult = new JSONObject(result);

                //get the "results" array
                JSONArray resultsArray = jsonResult.getJSONArray("results");

                for (int i = 0; i < resultsArray.length(); i++) {
                    Log.d(TAG, "result " + i);

                    //the current item's object:
                    JSONObject place = resultsArray.getJSONObject(i);

                    //get the relevant fields:
                    String address = place.getString("formatted_address");
                    String name = place.getString("name");
                    JSONObject location = place.getJSONObject("geometry");
                    location = location.getJSONObject("location");
                    double lat = location.getDouble("lat");
                    double lng = location.getDouble("lng");
                    String icon = place.getString("icon");

                    Log.d(TAG, name);
                    Log.d(TAG, icon);
                    Log.d(TAG, address);
                    Log.d(TAG, lat + "");
                    Log.d(TAG, lat + "");

                    // prepare an ContentValues to insert:
                    ContentValues values = new ContentValues();
                    values.put(PlacesContract.Places.NAME, name);
                    values.put(PlacesContract.Places.ADDRESS, address);
                    values.put(PlacesContract.Places.LAT, lat);
                    values.put(PlacesContract.Places.LNG, lng);
                    values.put(PlacesContract.Places.ICON, icon);

                    //insert into the provider (places table)
                    getContentResolver().insert(PlacesContract.Places.CONTENT_URI, values);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
// ----------------------------------------------------------------------------
    /**
     * Created by Gilly on 9/9/2015.
     *
        /**
         * handles the search action for this service
         *
         * @param query - the text to search for
         */
        private void handleNearBy(String query ,double lat, double lng) {

            //check if text is valid:
            if (query == null || query.length() < 2) {
                //don't search for queries less then 2 letters
                return;
            }

            // first - delete all data from the provider (places table):
            getContentResolver().delete(PlacesContract.Places.CONTENT_URI, null, null);

            // search:
            String queryString = null;
            try {
                queryString = ""
                        + "keyword=" + URLEncoder.encode(query, "utf-8")
                        + "&key=" + URLEncoder.encode(API_KEY, "utf-8")
                        + "&location=" + URLEncoder.encode(lat+"," +lng, "utf-8")
                        + "&radius=" + URLEncoder.encode(SEARCH_RADIUS+"", "utf-8");

            } catch (UnsupportedEncodingException e) {
            }
            String result = HttpHandler.get(SEARCH_APPI , queryString);
            Log.d(TAG,"the results" + result);

            if (result == null){

                LocalBroadcastManager lbm = LocalBroadcastManager.getInstance(this);
                Intent broadcastIntent = new Intent(ACTION_RESULTS);
                lbm.sendBroadcast(broadcastIntent);

            }else {
                // parse the json response:
                try {

                    //the response object:
                    JSONObject jsonResult = new JSONObject(result);

                    //get the "results" array
                    JSONArray resultsArray = jsonResult.getJSONArray("results");

                    for (int i = 0; i < resultsArray.length(); i++) {
                        Log.d(TAG, "result " + i);

                        //the current item's object:
                        JSONObject place = resultsArray.getJSONObject(i);

                        //get the relevant fields:
                        String address = place.getString("vicinity");
                        String name = place.getString("name");
                        JSONObject location = place.getJSONObject("geometry");
                        location = location.getJSONObject("location");
                        double lat2 = location.getDouble("lat");
                        double lng2 = location.getDouble("lng");
                        String icon = place.getString("icon");

                        Log.d(TAG, name);
                        Log.d(TAG, icon);
                        Log.d(TAG, address); Log.d(TAG, lat2 + ""); Log.d(TAG, lat2 + "");

                        // prepare an ContentValues to insert:
                        ContentValues values = new ContentValues();
                        values.put(PlacesContract.Places.NAME, name);
                        values.put(PlacesContract.Places.ADDRESS, address);
                        values.put(PlacesContract.Places.LAT, lat2);
                        values.put(PlacesContract.Places.LNG, lng2);
                        values.put(PlacesContract.Places.ICON, icon);

                        //insert into the provider (places table)
                        getContentResolver().insert(PlacesContract.Places.CONTENT_URI, values);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            LocalBroadcastManager lbm = LocalBroadcastManager.getInstance(this);
            Intent broadcastIntent = new Intent(ACTION_SWIPE_REFRESH);
            lbm.sendBroadcast(broadcastIntent);

        }
    }
