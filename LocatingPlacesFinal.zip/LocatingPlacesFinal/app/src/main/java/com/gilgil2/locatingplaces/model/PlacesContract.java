package com.gilgil2.locatingplaces.model;

import android.net.Uri;

/**
 * Created by Gilly on 9/8/2015.
 */

    public class PlacesContract {

        /** base  AUTHORITY for the provider */
        public final static String AUTHORITY = "com.gilgil2.locatingplaces.provider";

        /**
         * Places table:<br>
         * holds the latest search results for places
         * @author Yak
         *
         */
        public static class Places {
            /**
             * table name
             * */
            public final static String TABLE_NAME = "places";

            /**
             * uri for the places table<br>
             * <b>content://com.gilgil2.locatingplaces</b>
             */
            public final static Uri CONTENT_URI = Uri.parse("content://" + AUTHORITY + "/" + TABLE_NAME);


            // table columns

            /** id (type: INTEGER)*/
            public final static String _ID = "_id";

            /** place's name (type: TEXT)*/
            public final static String NAME = "name";

            /** place's address (type: TEXT)*/
            public final static String ADDRESS = "address";

            // places lat (type: REAL)
            public final static String LAT = "lat";

            // places lat (type: REAL)
            public final static String LNG = "lng";

            // places icon (type: TEXT)
            public final static String ICON = "icon";

        }
    public static class Favorite {
        /**
         * table name
         * */
        public final static String TABLE_NAME = "favorite";

        /**
         * uri for the favorite table<br>
         * <b>content://com.gilgil2.locatingplaces</b>
         */
        public final static Uri CONTENT_URI = Uri.parse("content://" + AUTHORITY + "/" + TABLE_NAME);


        // table columns

        /** id (type: INTEGER)*/
        public final static String _ID = "_id";

        /** place's name (type: TEXT)*/
        public final static String NAME = "name";

        /** place's address (type: TEXT)*/
        public final static String ADDRESS = "address";

        // places lat (type: REAL)
        public final static String LAT = "lat";

        // places lat (type: REAL)
        public final static String LNG = "lng";

        // places icon (type: TEXT)
        public final static String ICON = "icon";

    }
}

