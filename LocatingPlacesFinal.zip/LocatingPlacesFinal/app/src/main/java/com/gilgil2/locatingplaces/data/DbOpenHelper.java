package com.gilgil2.locatingplaces.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.gilgil2.locatingplaces.model.PlacesContract;

/**
 * Created by Gilly on 9/8/2015.
 */
public class DbOpenHelper extends SQLiteOpenHelper {

    /** the current database version */
    private static final int DB_VERSION = 2;

    /** the database file name */
    private static final String DB_NAME = "places.db";

    public DbOpenHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

      @Override
    public void onCreate(SQLiteDatabase db) {

        // create the tables:
        String sql1 =
                "CREATE TABLE " + PlacesContract.Places.TABLE_NAME
                        +"("
                        + PlacesContract.Places._ID + " INTEGER PRIMARY KEY AUTOINCREMENT ,"
                        + PlacesContract.Places.NAME + " TEXT ,"
                        + PlacesContract.Places.ADDRESS + " TEXT ,"
                        + PlacesContract.Places.LAT + " REAL ,"
                        + PlacesContract.Places.LNG + " REAL ,"
                        + PlacesContract.Places.ICON + " TEXT"
                        + ")";
        db.execSQL(sql1);

          // create the tables:
          String sql2 =
                  "CREATE TABLE " + PlacesContract.Favorite.TABLE_NAME
                          +"("
                          + PlacesContract.Favorite._ID + " INTEGER PRIMARY KEY AUTOINCREMENT ,"
                          + PlacesContract.Favorite.NAME + " TEXT ,"
                          + PlacesContract.Favorite.ADDRESS + " TEXT ,"
                          + PlacesContract.Favorite.LAT + " REAL ,"
                          + PlacesContract.Favorite.LNG + " REAL ,"
                          + PlacesContract.Favorite.ICON + " TEXT"
                          + ")";
          db.execSQL(sql2);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        // delete the tables:
        String sql1 = "DROP TABLE IF EXISTS " + PlacesContract.Places.TABLE_NAME;
        db.execSQL(sql1);

        String sql2 = "DROP TABLE IF EXISTS " + PlacesContract.Favorite.TABLE_NAME;
        db.execSQL(sql2);

        //recreate the tables:
        onCreate(db);
    }


}
