package com.gilgil2.locatingplaces.model;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.v4.util.LruCache;
import android.support.v4.widget.CursorAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.gilgil2.locatingplaces.R;
import com.gilgil2.locatingplaces.util.HttpHandler;

/**
 * Created by Gilly on 9/20/2015.
 */
public class FavoritsAdapter extends CursorAdapter {

    private LruCache<String, Bitmap> bitmapCache;
    private double myLat;
    private double myLng;

    // ** view holder class
    // ** this will holder the sub-views and the id for each view-item in the list.
    class ViewHolder {
        long id;
        TextView textname1;
        TextView textaddress1;
        TextView textdistance;
        ImageView imageicon1;
    }

    public FavoritsAdapter(Context context, Cursor c) {
        super(context, c);

        // prepare a cache for the images.
        // key : the url. value : the bitmap.
        //max size : 4 MB
        int numImages = 4 * 1024 * 1024;
        this.bitmapCache = new LruCache<String, Bitmap>(numImages) {
            @Override
            protected int sizeOf(String key, Bitmap value) {
                // this is how to calculate a bitmap size in bytes.
                // (bytes-in-a-row * height)
                return value.getRowBytes() * value.getHeight();
            }
        };
    }
    // ----------------------------------------------------------------------------

    public void setLocation(double lat, double lng){

    this.myLat = lat;
    this.myLng = lng;
     }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup viewGroup) {
        //new view:

        View view = LayoutInflater.from(context).inflate(R.layout.favorits_adapter, viewGroup, false);

        // create view holder (only create for a new view)
        // and find the sub views:
        ViewHolder holder = new ViewHolder();
        holder.textname1 = (TextView) view.findViewById(R.id.textname1);
        holder.textaddress1 = (TextView) view.findViewById(R.id.textaddress1);
        holder.textdistance = (TextView) view.findViewById(R.id.textdistance1);
        holder.imageicon1 = (ImageView) view.findViewById(R.id.imageicon1);

        //set as the view tag:
        view.setTag(holder);

        return view;
    }
    // ----------------------------------------------------------------------------

    @Override
    public void bindView(View view, Context context, Cursor cursor) {

        String units;

        // data (from cursor):
        long id = cursor.getLong(cursor.getColumnIndex(PlacesContract.Favorite._ID));
        String name = cursor.getString(cursor.getColumnIndex(PlacesContract.Favorite.NAME));
        String address = cursor.getString(cursor.getColumnIndex(PlacesContract.Favorite.ADDRESS));
        String imageicon = cursor.getString(cursor.getColumnIndex(PlacesContract.Favorite.ICON));
        double lat = cursor.getDouble(cursor.getColumnIndex(PlacesContract.Favorite.LAT));
        double lng =cursor.getDouble(cursor.getColumnIndex(PlacesContract.Favorite.LNG));

        // get the view holder
        ViewHolder holder = (ViewHolder) view.getTag();

        // set/update its place id:
        holder.id = id;
        //bind:
        holder.textname1.setText(name);
        holder.textaddress1.setText(address);
        double dist = haversine(lat,lng, myLat,myLng);
        // the chosen distance type
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        units = prefs.getString("units","km");
        if (units.equals("km")) {
            holder.textdistance.setText(String.format("%.2f KM", dist));
        }else {
            holder.textdistance.setText(String.format("%.2f MILS", dist * 0.62137));
        }


        // do we have the bitmap in the cache?
        Bitmap cachedBmp = bitmapCache.get(imageicon);
        if (cachedBmp != null) {
            // we do - just use it!
            holder.imageicon1.setVisibility(View.VISIBLE);
            holder.imageicon1.setImageBitmap(cachedBmp);
        } else {
            //we don't... get it async
            //until the image is downloaded - hide the image view:
            holder.imageicon1.setVisibility(View.INVISIBLE);
            GetIconTask task = new GetIconTask(id, holder);
            task.execute(imageicon);
        }
    }

    // ----------------------------------------------------------------------------
    class GetIconTask extends AsyncTask<String, Void, Bitmap> {


        private final long id;
        private final ViewHolder holder;

        public GetIconTask(long id, ViewHolder holder) {
            this.id = id;
            this.holder = holder;
        }

        @Override
        protected Bitmap doInBackground(String... params) {
            //download:
            String address = params[0];
            Bitmap bitmap = HttpHandler.getBitmap(address, null);

            //save it in the cache for later:
            if (bitmap != null) {
                bitmapCache.put(address, bitmap);
            }
            return bitmap;
        }
        // ----------------------------------------------------------------------------

        @Override
        protected void onPostExecute(Bitmap result) {

            // check - is the view's holder still holding the same place we started the download for?
            // or did the view get recycled and now displaying a different place?
            if (id == holder.id) {
                // it's still the same place!

                //restore the visibility and show the thumb
                holder.imageicon1.setVisibility(View.VISIBLE);

                if (result != null) {
                    holder.imageicon1.setImageBitmap(result);
                } else {
                    //error in download...
                    holder.imageicon1.setImageResource(R.mipmap.ic_launcher);
                }
            }
        }
    }
    /**
     * Calculates the distance in km between two lat/long points
     * using the haversine formula
     */
    public static double haversine(double lat, double lng, double myLat, double myLng) {
        int r = 6371; // average radius of the earth in km
        double dLat = Math.toRadians(myLat - lat);
        double dLon = Math.toRadians(myLng - lng);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(lat)) * Math.cos(Math.toRadians(myLat))
                        * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        double d = r * c;
        return d;
    }
}