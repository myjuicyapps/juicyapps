package com.gilgil2.locatingplaces.view;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.gilgil2.locatingplaces.R;
import com.gilgil2.locatingplaces.data.PlacesProvider;
import com.gilgil2.locatingplaces.model.FavoritsAdapter;
import com.gilgil2.locatingplaces.model.PlacesAdapter;
import com.gilgil2.locatingplaces.model.PlacesContract;

/**
 * Created by Gilly on 9/19/2015.
 */
public class FragFavorits extends Fragment  implements LoaderManager.LoaderCallbacks<Cursor>, LocationListener, AdapterView.OnItemClickListener {

    private static final String TAG = "FragFavorits" ;
    //public static final String ACTION_FAVORITS = "com.gilgil2.locatingplaces.action.FAVORITES";
    private ListView listFav;
    FavoritsAdapter adapter;
    // location manager and provider:
    private LocationManager locationManager;
    private String provider;
    Location current_location;

    public static FragFavorits newInstance() {

        Bundle args = new Bundle();
        FragFavorits fragment = new FragFavorits();
        fragment.setArguments(args);
        return fragment;
    }

    // ----------------------------------------------------------------------------
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Log.d(TAG, "onCreateView (list)");


        View view = inflater.inflate(R.layout.frag_favorits, container, false);

        listFav = (ListView) view.findViewById(R.id.listFav);

        // get an instance of the location service:
        locationManager = (LocationManager)(getActivity().getSystemService(Context.LOCATION_SERVICE));

        // get the best location-provider that matches the criteria we need:
        // the criteria depends on what we actually need
        // (for example, low battery and we need speed detection)
        Criteria criteria = new Criteria();
        criteria.setAccuracy(Criteria.ACCURACY_FINE);
        provider = locationManager.getBestProvider(criteria, true);

        // try to get the last known location available on the selected provider
        current_location = locationManager.getLastKnownLocation(provider);

        listFav.setOnItemClickListener(this);
        registerForContextMenu(listFav);

        adapter = new FavoritsAdapter(getActivity(), null);
        listFav.setAdapter(adapter);

        getLoaderManager().initLoader(1, null, this);

        return view;
    }
    // ----------------------------------------------------------------------------

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        //the uri - places table in the provider
        Uri uri = PlacesContract.Favorite.CONTENT_URI;

        // create the loader:
        return new CursorLoader(getActivity(), uri, null, null, null, PlacesContract.Favorite.NAME + " asc");
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {

        adapter.swapCursor(cursor);
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {

        adapter.swapCursor(null);
    }
    // ----------------------------------------------------------------------------
    // -- create the context menu
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {

        super.onCreateContextMenu(menu, v, menuInfo);

        getActivity().getMenuInflater().inflate(R.menu.item_delet, menu);
    }
    // ----------------------------------------------------------------------------

    public boolean onContextItemSelected(MenuItem item) {

        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        long id = info.id;

        switch (item.getItemId()) {
            case R.id.itemdelet:

                Cursor cursor = getActivity().getContentResolver().query(
                        PlacesContract.Favorite.CONTENT_URI,
                        null,
                        PlacesContract.Favorite._ID + " = ?",
                        new String[]{id + ""},
                        null);

                cursor.moveToNext();
                //PlacesProvider.delete(id);
                //del  the selected place
                getActivity().getContentResolver().delete( PlacesContract.Favorite.CONTENT_URI, PlacesContract.Favorite._ID + "=?",
                        new String[]{id + ""});
                cursor.close();
                return true;

            case R.id.itemshares:

                //get the place:
                Cursor cursor2 = getActivity().getContentResolver().query(
                        PlacesContract.Favorite.CONTENT_URI,
                        null,
                        PlacesContract.Favorite._ID + " = ?",
                        new String[]{id + ""},
                        null);

                cursor2.moveToNext();
                String name2 = cursor2.getString(cursor2.getColumnIndex(PlacesContract.Favorite.NAME));
                String address2 = cursor2.getString(cursor2.getColumnIndex(PlacesContract.Favorite.ADDRESS));
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, name2 + ", " + address2);
                startActivity(Intent.createChooser(i, "Share on:"));
                //we're done with the cursor
                //close it!
                cursor2.close();
                return true;

            default:
                return super.onContextItemSelected(item);
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        // got a new location:
        current_location = location;
        adapter.setLocation(location.getLatitude(), location.getLongitude());
        adapter.notifyDataSetChanged();
    }

    // ----------------------------------------------------------------------------
    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
        // there was a status change:

        // see what status it was
        // (it will be one of the following, according to the documentation)
        switch (status) {
            case LocationProvider.AVAILABLE:
                //Toast.makeText(getActivity(), "LOCATION AVAILABLE", Toast.LENGTH_SHORT).show();
                break;

            case LocationProvider.OUT_OF_SERVICE:
                //Toast.makeText(getActivity(), "LOCATION OUT_OF_SERVICE", Toast.LENGTH_SHORT).show();
                break;

            case LocationProvider.TEMPORARILY_UNAVAILABLE:
                //Toast.makeText(getActivity(), "LOCATION TEMPORARILY_UNAVAILABLE", Toast.LENGTH_SHORT).show();
                break;
        }
    }
    @Override
    public void onProviderEnabled(String provider) {
        // the provider was enabled:
    }

    @Override
    public void onProviderDisabled(String provider) {
        // the provider was disabled:
    }
    // ----------------------------------------------------------------------------
    // -- we will listen to location changed only when the activity is displayed
    @Override
    public void onResume() {
        super.onResume();
        // listen to changes if location that are bigger then 5000 milliseconds or 1 meter
        locationManager.requestLocationUpdates(provider, 5000, 1, this);

        adapter.notifyDataSetChanged();
    }

    // ----------------------------------------------------------------------------
    // -- we will stop listening to location changed when the activity is not displayed
    @Override
    public void onPause() {
        super.onPause();
        locationManager.removeUpdates(this);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onDestroy() {
        super.onDestroy();

    }
}
