package com.gilgil2.locatingplaces.view;

import android.app.Activity;


import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.widget.SwipeRefreshLayout;
import android.util.Log;

import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.gilgil2.locatingplaces.R;
import com.gilgil2.locatingplaces.control.SearchPlacesService;
import com.gilgil2.locatingplaces.model.Place;
import com.gilgil2.locatingplaces.model.PlacesAdapter;
import com.gilgil2.locatingplaces.model.PlacesContract;

/**
 * Created by Gilly on 9/6/2015.
 */
public class FragList  extends Fragment implements LoaderManager.LoaderCallbacks<Cursor>, View.OnClickListener, LocationListener, AdapterView.OnItemClickListener, TextView.OnEditorActionListener, SwipeRefreshLayout.OnRefreshListener {

    private static final String TAG = "FragList";
    private EditText txtsearch;
    private Button btnnearby;
    private Button btnglobal;
    private ListView searchresult;
    private SwipeRefreshLayout swipeRefreshLayout;

    // location manager and provider:
    private LocationManager locationManager;
    private String provider;
    Location current_location;
    private InternetConnectivityReceiver connectivityreceiver;
    private SearchResults searchresults;
    private SwipeRefresh swiperefresh;


    /** the list adapter */
    PlacesAdapter adapter;

    public static FragList newInstance() {

        Bundle args = new Bundle();
        FragList fragment = new FragList();
        fragment.setArguments(args);
        return fragment;
    }

     FragListListener listener;
    // ----------------------------------------------------------------------------
    @Override
    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        return true;
    }

    // *************************************************************
    // ** A Listener-interface that the activity must implement!
    public interface FragListListener {
       void onPlaceSelected(Place place);
   }

    // ----------------------------------------------------------------------------
    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

        // try to set the activity as the listener:
        try {
            listener = (FragListListener) activity;
        } catch (ClassCastException e) {
            // oops - the activity does not implement FragMenuListener!
            throw new ClassCastException(activity.toString()
                    + " must implement FragMenuListener!");
        }

    }
    // ----------------------------------------------------------------------------
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Log.d(TAG, "onCreateView (list)");

        View view = inflater.inflate(R.layout.frag_list, container, false);

        // set up the view here...
        // use view.findViewById() to find the views in the layout
        txtsearch = (EditText)view.findViewById(R.id.txtsearch);
        btnnearby = (Button) view.findViewById(R.id.btnnearby);
        btnglobal = (Button) view.findViewById(R.id.btnglobal);
        searchresult = (ListView) view.findViewById(R.id.searchresult);
        swipeRefreshLayout = (SwipeRefreshLayout) view.findViewById(R.id.swipeContainer);

        // get an instance of the location service:
        locationManager = (LocationManager)(getActivity().getSystemService(Context.LOCATION_SERVICE));

        // get the best location-provider that matches the criteria we need:
        // the criteria depends on what we actually need
        // (for example, low battery and we need speed detection)
        Criteria criteria = new Criteria();
        criteria.setAccuracy(Criteria.ACCURACY_FINE);
        provider = locationManager.getBestProvider(criteria, true);

        // try to get the last known location available on the selected provider
        current_location = locationManager.getLastKnownLocation(provider);

        // also :  setup an onclick for the button:

        btnnearby.setOnClickListener(this);
        btnglobal.setOnClickListener(this);
        searchresult.setOnItemClickListener(this);
        txtsearch.setOnEditorActionListener(this);
        registerForContextMenu(searchresult);
        swipeRefreshLayout.setOnRefreshListener(this);

        // create and register the receivers
        LocalBroadcastManager lbm = LocalBroadcastManager.getInstance(getActivity());

        // THE RECEIVER - create and register:
        // the intent filter will be the action -ACTION_INTERNET_CONNECTION
        connectivityreceiver = new InternetConnectivityReceiver();
        IntentFilter filterConnection = new IntentFilter (SearchPlacesService.ACTION_INTERNET_CONNECTION);
        lbm.registerReceiver(connectivityreceiver,filterConnection);

        // the intent filter will be the action -ACTION_RESULTS
        searchresults = new SearchResults();
        IntentFilter filterRsults = new IntentFilter (SearchPlacesService.ACTION_RESULTS);
        lbm.registerReceiver(searchresults,filterRsults);

        // the intent filter will be the action -ACTION_SWIPE_REFRESH
        swiperefresh = new SwipeRefresh();
        IntentFilter filterRefresh = new IntentFilter (SearchPlacesService.ACTION_SWIPE_REFRESH);
        lbm.registerReceiver(swiperefresh,filterRefresh);


        // adapter + list (start with null cursor)
        adapter = new PlacesAdapter(getActivity(), null);
        searchresult.setAdapter(adapter);

        getLoaderManager().initLoader(1, null, this);

        return view;
    }

    // ----------------------------------------------------------------------------

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        //the uri - places table in the provider
        Uri uri = PlacesContract.Places.CONTENT_URI;

        // create the loader:
        return new CursorLoader(getActivity(), uri, null, null, null, PlacesContract.Places.NAME + " asc");
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {

        adapter.swapCursor(cursor);
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {

        adapter.swapCursor(null);
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){
            case R.id.btnnearby:
               doNearbySearch();
                // get preferences editor:
                SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getActivity());
                SharedPreferences.Editor editor = sp.edit();

                String text = txtsearch.getText().toString();
                editor.putString("txtsearch", text);
                editor.putBoolean("searchNearBy", true);
                closeKeyBaord(btnnearby);
                // commit
                editor.commit();
                break;

            case R.id.btnglobal:
                doTextSearch();
                // get preferences editor:
                SharedPreferences sp2 = PreferenceManager.getDefaultSharedPreferences(getActivity());
                SharedPreferences.Editor editor2 = sp2.edit();

                String text2 = txtsearch.getText().toString();
                editor2.putString("txtsearch", text2);
                editor2.putBoolean("searcByText", false);
                closeKeyBaord(btnglobal);
                // commit
                editor2.commit();
                break;
        }
    }

    // ----------------------------------------------------------------------------

    // helper function - start the search service:
    /**
     * helper method<br>
     * this will start the search service and give it the query from the editText<br>
     * (will verify 2+ letters)
     */
    private void doTextSearch() {

        //get the text:
        String query =  txtsearch.getText().toString();

        if (query.length()>1){
            //call service with extra
            Intent intent = new Intent(getActivity(),SearchPlacesService.class);
            intent.setAction(SearchPlacesService.ACTION_SEARCH);
            intent.putExtra(SearchPlacesService.EXTRA_QUERY, query);

            getActivity().startService(intent);
        }else{
            Toast.makeText(getActivity(), "enter at least 2 letters...", Toast.LENGTH_SHORT).show();
            // close the indicator if were not going to the service
            swipeRefreshLayout.setRefreshing(false);
        }

    }

    // ----------------------------------------------------------------------------

    // helper function - start the searchnearby service:
    /**
     * helper method<br>
     * this will start the search service and give it the query from the editText<br>
     * (will verify 2+ letters)
     */

    private void doNearbySearch() {

        //get the text:
        String query =  txtsearch.getText().toString();
        double lat = current_location.getLatitude();
        double lng = current_location.getLongitude();

        if (query.length()>1){
            //call service with extras
            Intent intent = new Intent(getActivity(),SearchPlacesService.class);
            intent.setAction(SearchPlacesService.ACTION_NEAR_BY);
            intent.putExtra(SearchPlacesService.EXTRA_QUERY, query);
            intent.putExtra(SearchPlacesService.EXTRA_LAT, lat);
            intent.putExtra(SearchPlacesService.EXTRA_LNG, lng);

            getActivity().startService(intent);
        }else{
            Toast.makeText(getActivity(), "enter at least 2 letters...", Toast.LENGTH_SHORT).show();
            // close the indicator if were not going to the service
            swipeRefreshLayout.setRefreshing(false);
        }
    }

    // ----------------------------------------------------------------------------
    // -- we will listen to location changed only when the activity is displayed
    @Override
    public void onResume() {
        super.onResume();
        // listen to changes if location that are bigger then 5000 milliseconds or 1 meter
        locationManager.requestLocationUpdates(provider, 5000, 1, this);

        // -- get the current saved prefs (from the shared-preferences):
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getActivity());

        //retrieve the data:
        String textsearch = prefs.getString("txtsearch", "");

        //set the data to the editTexts:
        txtsearch.setText(textsearch);

        adapter.notifyDataSetChanged();

    }

    // ----------------------------------------------------------------------------
    // -- we will stop listening to location changed when the activity is not displayed
    @Override
    public void onPause() {
        super.onPause();
        locationManager.removeUpdates(this);

        // get preferences editor:
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getActivity());
        SharedPreferences.Editor editor = sp.edit();

        // put data:
        String text = txtsearch.getText().toString();
        editor.putString("txtsearch", text);

        // commit
        editor.commit();
    }

    // ----------------------------------------------------------------------------
    // -- Location callbacks
    @Override
    public void onLocationChanged(Location location) {
        // got a new location:
        current_location = location;
        adapter.setLocation(location.getLatitude(), location.getLongitude());
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onProviderEnabled(String provider) {
        // the provider was enabled:
    }

    @Override
    public void onProviderDisabled(String provider) {
        // the provider was disabled:
    }
    // ----------------------------------------------------------------------------
    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
        // there was a status change:

        // see what status it was
        // (it will be one of the following, according to the documentation)
        switch (status) {
            case LocationProvider.AVAILABLE:
               // Toast.makeText(getActivity(), "LOCATION AVAILABLE", Toast.LENGTH_SHORT).show();
                break;

            case LocationProvider.OUT_OF_SERVICE:
                //Toast.makeText(getActivity(), "LOCATION OUT_OF_SERVICE", Toast.LENGTH_SHORT).show();
                break;

            case LocationProvider.TEMPORARILY_UNAVAILABLE:
               // Toast.makeText(getActivity(), "LOCATION TEMPORARILY_UNAVAILABLE", Toast.LENGTH_SHORT).show();
                break;
        }
    }

    // ----------------------------------------------------------------------------
    // -- create the context menu
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {

        super.onCreateContextMenu(menu, v, menuInfo);

       getActivity().getMenuInflater().inflate(R.menu.item_favorits_share, menu);
    }

    // ----------------------------------------------------------------------------
    @Override
    public boolean onContextItemSelected(MenuItem item) {

        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        long id = info.id;

        switch (item.getItemId()) {

            case R.id.itemfav:

                Intent intent = new Intent(getActivity(),FavoritsActivity.class);
                startActivity(intent);

                //get the place:
                Cursor cursor = getActivity().getContentResolver().query(
                        PlacesContract.Places.CONTENT_URI,
                        null,
                        PlacesContract.Places._ID + " = ?",
                        new String[]{id + ""},
                        null);


                cursor.moveToNext();
                String name = cursor.getString(cursor.getColumnIndex(PlacesContract.Places.NAME));
                String address = cursor.getString(cursor.getColumnIndex(PlacesContract.Places.ADDRESS));
                String imageicon = cursor.getString(cursor.getColumnIndex(PlacesContract.Places.ICON));
                double lat = cursor.getDouble(cursor.getColumnIndex(PlacesContract.Places.LAT));
                double lng =cursor.getDouble(cursor.getColumnIndex(PlacesContract.Places.LNG));

                // fill the favorits table
                ContentValues values = new ContentValues();
                values.put(PlacesContract.Favorite.NAME, name);
                values.put(PlacesContract.Favorite.ADDRESS, address);
                values.put(PlacesContract.Favorite.LAT, lat);
                values.put(PlacesContract.Favorite.LAT, lng);
                values.put(PlacesContract.Favorite.ICON, imageicon);

                //insert into the provider (places table)
               getActivity().getContentResolver().insert(PlacesContract.Favorite.CONTENT_URI, values);
                //we're done with the cursor
                //close it!
                cursor.close();
                return true;

            case R.id.itemshare:

                //get the place:
                Cursor cursor2 = getActivity().getContentResolver().query(
                        PlacesContract.Places.CONTENT_URI,
                        null,
                        PlacesContract.Places._ID + " = ?",
                        new String[]{id + ""},
                        null);

                cursor2.moveToNext();
                String name2 = cursor2.getString(cursor2.getColumnIndex(PlacesContract.Places.NAME));
                String address2 = cursor2.getString(cursor2.getColumnIndex(PlacesContract.Places.ADDRESS));
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, name2 + ", " + address2);
                startActivity(Intent.createChooser(i, "Share on:"));
                //we're done with the cursor
                //close it!
                cursor2.close();
                return true;

            default:
                return super.onContextItemSelected(item);
        }
    }

    // ----------------------------------------------------------------------------
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

        //get the place:
        Cursor cursor = getActivity().getContentResolver().query(
                PlacesContract.Places.CONTENT_URI,
                null,
                PlacesContract.Places._ID + " = ?",
                new String[]{id + ""},
                null);

        cursor.moveToNext();
        String name = cursor.getString(cursor.getColumnIndex(PlacesContract.Places.NAME));
        String address = cursor.getString(cursor.getColumnIndex(PlacesContract.Places.ADDRESS));
        double lat = cursor.getDouble(cursor.getColumnIndex(PlacesContract.Places.LAT));
        double lng =cursor.getDouble(cursor.getColumnIndex(PlacesContract.Places.LNG));

        Place place = new Place(name,address,lat,lng);

        //send it to the listener:
        listener.onPlaceSelected(place);

        //we're done with the cursor
        //close it!
        cursor.close();

    }
    // ----------------------------------------------------------------------------
    @Override
    public void onRefresh() {

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getActivity());
        //retrieve the data:
        boolean searchNearBy = prefs.getBoolean("searchNearBy", true);
        //boolean searcByText = prefs.getBoolean("searcByText", false);

        if (searchNearBy) {
            doNearbySearch();

        }else {
            doTextSearch();

        }
    }
    // ----------------------------------------------------------------------------
    // -- RECEIVER CLASS - for broadcasts from internet connection service
    class InternetConnectivityReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {

            Toast.makeText(getActivity(), " NO WIFI CONNECTION ", Toast.LENGTH_SHORT).show();
        }
    }
    // ----------------------------------------------------------------------------
    // -- RECEIVER CLASS - for broadcasts from search results service
    class SearchResults extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {

            Toast.makeText(getActivity(), "NO RESULTS...TRY AGAIN ", Toast.LENGTH_SHORT).show();
        }
    }

    // ----------------------------------------------------------------------------
    // -- RECEIVER CLASS - for broadcasts from search results service
    class SwipeRefresh extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {

            swipeRefreshLayout.setRefreshing(false);
        }
    }
    // ----------------------------------------------------------------------------
    @Override
    public void onDestroy() {
        super.onDestroy();
        LocalBroadcastManager lbm = LocalBroadcastManager.getInstance(getActivity());
        lbm.unregisterReceiver(connectivityreceiver);
        lbm.unregisterReceiver(searchresults);
        lbm.unregisterReceiver(swiperefresh);
    }

    // ----------------------------------------------------------------------------
    // hiding the soft keyboard
    public void closeKeyBaord(Button btn) {
        InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(getActivity().INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(btn.getWindowToken(), 0);
    }
}

