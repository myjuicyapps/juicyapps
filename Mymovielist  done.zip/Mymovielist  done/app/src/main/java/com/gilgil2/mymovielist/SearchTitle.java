package com.gilgil2.mymovielist;

/**
 * Created by Gilly on 7/23/2015.
 */
public class SearchTitle {


    private String id;
    private String titleresult;
    private String year;

    public SearchTitle(String titleresult, String id, String year) {
        this.id = id;
        this.titleresult = titleresult;
        this.year = year;
    }



    public String toString() {

        return titleresult + year;
    }

    public String getYear() {return year;}

    public void setYear(String year) {this.year = year;}

    public String getId() {return id;}

    public void setId(String id) {
        this.id = id;
    }

    public String getTitleresult() {
        return titleresult;
    }

    public void setTitleresult(String titleresult) {
        this.titleresult = titleresult;
    }

}


