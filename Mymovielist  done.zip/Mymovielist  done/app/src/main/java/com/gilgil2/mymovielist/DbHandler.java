package com.gilgil2.mymovielist;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

/**
 * Created by Gilly on 7/19/2015.
 */
public class DbHandler {

    public static final String TAG = "DbHandler";


    private DbOpenHelper dbOpenHelper;

    public DbHandler(Context context) {
        dbOpenHelper = new DbOpenHelper(context);
    }

    public long insert(Movie movie) {

        SQLiteDatabase db = dbOpenHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(DBconstants.MOVIE_TITLE, movie.getTitle());
        values.put(DBconstants.MOVIE_PLOT, movie.getPlot());
        values.put(DBconstants.MOVIE_URL, movie.getUrl());
        values.put(DBconstants.MOVIE_GENRE, movie.getGenre());
        values.put(DBconstants.MOVIE_YEAR, movie.getYear());
        //values.put(DBconstants.MOVIE_RATING, movie.getRating());
        //values.put(DBconstants.MOVIE_POSTER, movie.getPoster());


        long id = db.insertOrThrow(DBconstants.TABLE_NAME_MOVIES, null, values);
        db.close();

        return id;
    }

    public int update(Movie movie) {

        SQLiteDatabase db = dbOpenHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(DBconstants.MOVIE_TITLE, movie.getTitle());
        values.put(DBconstants.MOVIE_PLOT, movie.getPlot());
        values.put(DBconstants.MOVIE_URL, movie.getUrl());
        values.put(DBconstants.MOVIE_GENRE, movie.getGenre());
        values.put(DBconstants.MOVIE_YEAR, movie.getYear());
        //values.put(DBconstants.MOVIE_RATING, movie.getRating());
        //values.put(DBconstants.MOVIE_POSTER, movie.getPoster());

        int count = db.updateWithOnConflict(
                DBconstants.TABLE_NAME_MOVIES,
                values,
                DBconstants.MOVIE_ID + " =?",
                new String[]{String.valueOf(movie.getId()) + ""},
                SQLiteDatabase.CONFLICT_REPLACE);
        db.close();
        return count;
    }


    public int delete(long id) {

        SQLiteDatabase db = dbOpenHelper.getWritableDatabase();

        int count = db.delete(
                DBconstants.TABLE_NAME_MOVIES,
                DBconstants.MOVIE_ID + " =?",
                new String[]{String.valueOf(id) + ""});

        db.close();
        return count;

    }



    public Cursor queryAll() {

        SQLiteDatabase db = dbOpenHelper.getReadableDatabase();

        Cursor cursor = db.query(
                DBconstants.TABLE_NAME_MOVIES,
                null,
                null,
                null,
                null,
                null, DBconstants.MOVIE_TITLE + " COLLATE LOCALIZED ASC");

        return cursor;
    }

    public Movie query (long id){

        SQLiteDatabase db = dbOpenHelper.getReadableDatabase();

        Cursor cursor = db.query(
                DBconstants.TABLE_NAME_MOVIES,
                null,
                DBconstants.MOVIE_ID + "=?",
                new String[]{String.valueOf(id)},
                null,
                null,
                null);
        Log.d(TAG, "count = " + cursor.getCount());

        Movie movie = null;

        if (cursor.moveToNext()){

            String title = cursor.getString(cursor.getColumnIndex(DBconstants.MOVIE_TITLE));
            String plot = cursor.getString(cursor.getColumnIndex(DBconstants.MOVIE_PLOT));
            String url = cursor.getString(cursor.getColumnIndex(DBconstants.MOVIE_URL));
            String genre = cursor.getString(cursor.getColumnIndex(DBconstants.MOVIE_GENRE));
            String year = cursor.getString(cursor.getColumnIndex(DBconstants.MOVIE_YEAR));
            //String rating =  cursor.getString(cursor.getColumnIndex(DBconstants.MOVIE_RATING));
            //String poster = cursor.getString(cursor.getColumnIndex(DBconstants.MOVIE_POSTER));

            movie = new Movie(id,title, plot, url, genre, year);
        }

        cursor.close();

        return movie;

    }

    public void deleteTable() {

        SQLiteDatabase db = dbOpenHelper.getWritableDatabase();
        db.delete(DBconstants.TABLE_NAME_MOVIES, null, null);
        db.close();
    }

}
