package com.gilgil2.mymovielist;

import android.content.Context;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

/**
 * Created by Gilly on 7/21/2015.
 */
public class Movieadapter extends CursorAdapter {


    public Movieadapter(Context context, Cursor c) {
        super(context, c);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {

        return LayoutInflater.from(context).inflate(R.layout.movieprolist,parent,false);
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {

        long id = cursor.getLong(cursor.getColumnIndex(DBconstants.MOVIE_ID));
        String title = cursor.getString(cursor.getColumnIndex(DBconstants.MOVIE_TITLE));
        String genre = cursor.getString(cursor.getColumnIndex(DBconstants.MOVIE_GENRE));
        String poster = cursor.getString(cursor.getColumnIndex(DBconstants.MOVIE_URL));
        String year = cursor.getString(cursor.getColumnIndex(DBconstants.MOVIE_YEAR));
        //double rate = cursor.getDouble(cursor.getColumnIndex(DBconstants.MOVIE_RATING));

        TextView movietitle = (TextView)view.findViewById(R.id.movietitle);
        TextView moviegenre = (TextView)view.findViewById(R.id.moviegenre);
        TextView movieyear = (TextView)view.findViewById(R.id.movieyear);
       // RatingBar ratingBar = (RatingBar) view.findViewById(R.id.ratingBar2);
        ImageView posterview = (ImageView) view.findViewById(R.id.posterview);

        movietitle.setText(title);
        moviegenre.setText(genre);
        movieyear.setText(year);
        //ratingBar.setRating((float) rate);

        //posterview.setImageDrawable(Drawable.createFromPath(poster));

    }
}
