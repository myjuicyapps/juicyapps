package com.gilgil2.mymovielist;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;


public class Serchwebactivity extends ActionBarActivity implements View.OnClickListener, AdapterView.OnItemClickListener {

    public static final String TAG = "Serchwebactivity";

    public static final String URL_API = "http://www.omdbapi.com";


    private EditText searchtxt;
    private ListView Searchlist;
    private Button searchbtn;
    private String oldSearchResult;

    List<SearchTitle> titles;
    ArrayAdapter<SearchTitle> adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.serchwebactivity);

        searchtxt = (EditText) findViewById(R.id.searchtxt);
        Searchlist = (ListView) findViewById(R.id.Searchlist);
        searchbtn = (Button) findViewById(R.id.searchbtn);

        searchbtn.setOnClickListener(this);
        Searchlist.setOnItemClickListener(this);

        titles = new ArrayList<>();
        adapter = new ArrayAdapter<SearchTitle>(
                this,
                // R.layout.serchwebactivity,
                android.R.layout.simple_list_item_1,
                android.R.id.text1,
                titles);

        Searchlist.setAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_serchwebactivity, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();


        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.searchbtn:

                new Dothesearch().execute(URL_API);

                break;
        }
    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

        SearchTitle st = titles.get(position);
        Intent intent = new Intent(this, Details.class);
        intent.putExtra("imdbID", st.getId());
        intent.setAction(intent.ACTION_SEARCH);
        startActivity(intent);


    }

    class Dothesearch extends AsyncTask<String, Void, String> {

        ProgressDialog dialog;
        private String s;


        @Override
        protected void onPreExecute() {

            dialog = new ProgressDialog(Serchwebactivity.this);
            dialog.setTitle("searching");
            dialog.show();

            s = searchtxt.getText().toString();
        }

        @Override
        protected String doInBackground(String... params) {

            String queryString = null;

            try {
                queryString = "" +
                        "s=" + URLEncoder.encode(s, "utf-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            return HttpHandler.get(params[0], queryString);
        }

        protected void onPostExecute(String s) {

            oldSearchResult = s;
            dialog.dismiss();

            Log.d(TAG, "RES  = " + s);

            titles.clear();

            if (s == null) {

                Toast.makeText(Serchwebactivity.this, "error getting results...", Toast.LENGTH_LONG).show();
                return;
            }

            JSONObject json = null;
            try {
                json = new JSONObject(s);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            JSONArray searchArray = null;
            try {
                searchArray = json.getJSONArray("Search");
            } catch (JSONException e) {
                e.printStackTrace();
            }

            for (int i = 0; i < searchArray.length(); i++) {

                JSONObject SearchTitleObject = null;

                Log.d(TAG, "-----i=" + i);
                try {
                    SearchTitleObject = searchArray.getJSONObject(i);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                String titleresult = null;
                try {
                    titleresult = SearchTitleObject.getString("Title");
                    Log.d(TAG, "titleresult=" + titleresult);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                String year = null;
                try {
                    year = SearchTitleObject.getString("Year");
                    Log.d(TAG, "Year=" + year);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                String id = null;
                try {
                    id = SearchTitleObject.getString("imdbID");
                    Log.d(TAG, "id=" + id);
                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(Serchwebactivity.this, "error parsing results...", Toast.LENGTH_LONG).show();
                }
                titles.add(new SearchTitle(titleresult, id, year));
                Log.d(TAG, "added");

            }
            Log.d(TAG, "notified");
            adapter.notifyDataSetChanged();

        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putString("oldSearchResult", oldSearchResult);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        oldSearchResult = savedInstanceState.getString("oldSearchResult");

        if (oldSearchResult == null) {

        } else {

            JSONObject json = null;
            try {
                json = new JSONObject(oldSearchResult);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            JSONArray searchArray = null;
            try {
                searchArray = json.getJSONArray("Search");
            } catch (JSONException e) {
                e.printStackTrace();
            }

            for (int i = 0; i < searchArray.length(); i++) {

                JSONObject SearchTitleObject = null;

                Log.d(TAG, "-----i=" + i);
                try {
                    SearchTitleObject = searchArray.getJSONObject(i);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                String titleresult = null;
                try {
                    titleresult = SearchTitleObject.getString("Title");
                    Log.d(TAG, "titleresult=" + titleresult);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                String year = null;
                try {
                    year = SearchTitleObject.getString("Year");
                    Log.d(TAG, "Year=" + year);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                String id = null;
                try {
                    id = SearchTitleObject.getString("imdbID");
                    Log.d(TAG, "id=" + id);
                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(Serchwebactivity.this, "error parsing results...", Toast.LENGTH_LONG).show();
                }
                titles.add(new SearchTitle(titleresult, id, year));
                Log.d(TAG, "added");

            }
        }
    }
}
