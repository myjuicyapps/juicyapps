package com.gilgil2.mymovielist;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends ActionBarActivity implements View.OnClickListener, AdapterView.OnItemClickListener {

    private static final String TAG = "MainActivity";

    private Button btnadd;
    private ListView lstmovies;
    private static final int REQUEST_CODE_EDIT = 1;
    private static final int REQUEST_CODE_INSERT = 2;
    private DbHandler dbHandler;
    private Movieadapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnadd = (Button) findViewById(R.id.btnadd);
        lstmovies = (ListView) findViewById(R.id.lstmovies);

        btnadd.setOnClickListener(this);
        lstmovies.setOnItemClickListener(this);
        registerForContextMenu(lstmovies);

        dbHandler = new DbHandler(this);

        Cursor cursor = dbHandler.queryAll();
        startManagingCursor(cursor);

        adapter = new Movieadapter(this,cursor);
        lstmovies.setAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings){
            return true;
        }else if (id == R.id.deleteall) {
            dbHandler.deleteTable();
            refreshTheOutput();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.btnadd:


                showAlertDialog();
                break;

        }
    }

    private void showAlertDialog() {

        DialogInterface.OnClickListener listener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {

                    case DialogInterface.BUTTON_NEUTRAL:
                        Toast.makeText(MainActivity.this, "Canceld", Toast.LENGTH_SHORT).show();

                        break;

                    case DialogInterface.BUTTON_NEGATIVE:
                        Toast.makeText(MainActivity.this, "Web", Toast.LENGTH_SHORT).show();
                        Intent intent2 = new Intent(MainActivity.this, Serchwebactivity.class);
                        intent2.setAction(intent2.ACTION_SEARCH);
                        startActivity(intent2);

                        break;

                    case DialogInterface.BUTTON_POSITIVE:

                        Intent intent = new Intent(MainActivity.this,Details.class);
                        intent.setAction(intent.ACTION_INSERT);
                        startActivity(intent);


                        Toast.makeText(MainActivity.this, "Manually", Toast.LENGTH_SHORT).show();

                        break;

                }
            }
        };


        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("My movies");
        builder.setMessage("Add movie");
        builder.setIcon(R.mipmap.ic_launcher);


        builder.setNeutralButton("Cancel...", listener);
        builder.setNegativeButton("Search web...", listener);
        builder.setPositiveButton("Add manually...", listener);

        AlertDialog dialog = builder.create();

        dialog.show();

    }   @Override
        public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);

        //inflate the context menu
        getMenuInflater().inflate(R.menu.itemdeleteandedit,menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {


        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        long id = info.id;

        switch (item.getItemId()) {
            case R.id.itemdelete:
                dbHandler.delete(id);
                refreshTheOutput();
                return true;

            case R.id.itemedit:

                Intent intent = new Intent(this,Details.class);
                intent.setAction(Intent.ACTION_EDIT);

                intent.putExtra("id", id);

                startActivity(intent);

                return true;

            default:
                return super.onContextItemSelected(item);
        }
    }



    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

        Movie movie = dbHandler.query(id);

        Log.d(TAG, "handler query");
        Intent intent = new Intent(this,Details.class);

        intent.setAction(intent.ACTION_EDIT);
        intent.putExtra("id", id);

        startActivity(intent);

    }

    private void refreshTheOutput() {
        Log.d(TAG, "onRefreshClick");

        Cursor oldCursor = adapter.getCursor();
        Cursor newCursor = dbHandler.queryAll();

        startManagingCursor(newCursor);
        adapter.changeCursor(newCursor);

        oldCursor.close();;
        stopManagingCursor(oldCursor);
    }

}