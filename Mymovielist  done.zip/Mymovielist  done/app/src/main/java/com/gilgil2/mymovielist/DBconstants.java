package com.gilgil2.mymovielist;

/**
 * Created by Gilly on 7/16/2015.
 */
public class DBconstants {

    public static String TABLE_NAME_MOVIES =" movies";

    public static String MOVIE_ID = "_id";
    public static String MOVIE_TITLE = "title";
    public static String MOVIE_PLOT = "plot";
    public static String MOVIE_URL = "url";
    public static String MOVIE_GENRE = "genre";
    public static String MOVIE_YEAR = "year";
    //public static String MOVIE_RATING = "rating";
    //public static String MOVIE_POSTER = "poster";


}
