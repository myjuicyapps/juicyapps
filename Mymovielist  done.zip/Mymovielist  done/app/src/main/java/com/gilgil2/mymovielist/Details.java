package com.gilgil2.mymovielist;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;


public class Details extends ActionBarActivity implements View.OnClickListener {


    private Button btnsave;
    private EditText editText;
    private EditText editText2;
    private TextView bringposter;
    private EditText posterurl;
    private ImageView posterview;
    private EditText editText3;
    private TextView theyear;
    private Button btntrailer;


    DbHandler dbHandler;

    private static final String TAG = "Details";
    public static final String URL_API = "http://www.omdbapi.com";
    //public static final String ID = "imdbID";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        btnsave = (Button) findViewById(R.id.btnsave);
        editText = (EditText) findViewById(R.id.editText);
        editText2 = (EditText) findViewById(R.id.editText2);
        bringposter = (TextView) findViewById(R.id.bringposter);
        posterurl = (EditText) findViewById(R.id.posterurl);
        posterview = (ImageView) findViewById(R.id.posterview);
        editText3 = (EditText) findViewById(R.id.editText3);
        theyear = (TextView)findViewById(R.id.theyear);
        btntrailer = (Button) findViewById(R.id.btntrailer);


        btnsave.setOnClickListener(this);
        bringposter.setOnClickListener(this);
        btntrailer.setOnClickListener(this);

        dbHandler = new DbHandler(this);

        Intent callingIntent = getIntent();

        if (callingIntent.getAction().equals(Intent.ACTION_INSERT)) {

            Log.d(TAG, "tnis is a new movie");
        } else if (callingIntent.getAction().equals(Intent.ACTION_EDIT)) {

            Log.d(TAG, "tnis is an edited movie");

            long id = callingIntent.getLongExtra("id", 0);
            Log.d(TAG, "id=" + id);

            Movie movie = dbHandler.query(id);

            editText.setText(movie.getTitle());
            editText2.setText(movie.getPlot());
            posterurl.setText(movie.getUrl());
            editText3.setText(movie.getGenre());
            theyear.setText(movie.getYear());
            //posterview.setImageDrawable(Drawable.createFromPath(movie.getPoster()));


        } else if (callingIntent.getAction().equals(Intent.ACTION_SEARCH)) {

            Log.d(TAG, "tnis is a movie from search result ");
            String id = callingIntent.getStringExtra("imdbID");
            new Movieditales().execute(URL_API, id);
        }
    }


    @Override
    public void onClick(View v) {


        switch (v.getId()) {

            case R.id.btnsave:

                showAlertDialog();
                Log.d(TAG, "the save button");

                break;

            case R.id.bringposter:

                new GetImage().execute(posterurl.getText().toString());
                Toast.makeText(this, "The Poster", Toast.LENGTH_SHORT).show();

                break;

            case R.id.btntrailer:

                if(v.getId()== R.id.btntrailer){

                    String trailer = editText.getText().toString() + "trailer";
                    URLEncoder.encode(trailer);
                    Intent intent3 = new Intent(Intent.ACTION_VIEW, Uri.parse(
                            "https://www.youtube.com/results?search_query=" + trailer));
                    startActivity(intent3);
                    break;
                }


        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putString("title", editText.getText().toString());
        outState.putString("plot",editText2.getText().toString());
        outState.putString("genre",editText3.getText().toString());
        outState.putString("url",posterurl.getText().toString());
        outState.putString("year",theyear.getText().toString());
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        String title = savedInstanceState.getString("title");
        String plot = savedInstanceState.getString("plot");
        String genre = savedInstanceState.getString("genre");
        String url = savedInstanceState.getString("url");
        String year = savedInstanceState.getString("year");

        editText.setText(title);
        editText2.setText(plot);
        editText3.setText(genre);
        posterurl.setText(url);
        theyear.setText(year);
    }

    private void showAlertDialog() {

        DialogInterface.OnClickListener listener = new DialogInterface.OnClickListener() {

            String title = editText.getText().toString();
            String plot = editText2.getText().toString();
            String url = posterurl.getText().toString();
            String genre = editText3.getText().toString();
            String year = theyear.getText().toString();
            //String poster = posterview.getDrawable().toString();

            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {

                    case DialogInterface.BUTTON_NEUTRAL:

                        break;

                    case DialogInterface.BUTTON_POSITIVE:

                        Log.d(TAG, "save movie");

                        Intent callingIntent = getIntent();

                        if (callingIntent.getAction().equals(Intent.ACTION_INSERT)) {

                            Log.d(TAG, "tnis is a saved inserted movie");
                            Movie m = new Movie(title, plot, url, genre, year);
                            dbHandler.insert(m);
                            finish();
                        } else if (callingIntent.getAction().equals(Intent.ACTION_EDIT)) {

                            Log.d(TAG, "tnis is a saved edited movie");
                            long id = callingIntent.getLongExtra("id", 0);
                            Movie m = new Movie(id, title, plot, url, genre, year);
                            dbHandler.update(m);
                            finish();

                        } else if (callingIntent.getAction().equals(Intent.ACTION_SEARCH)) {

                            Log.d(TAG, "tnis is a saved searched movie");
                            Movie m = new Movie(title, plot, url, genre, year);
                            dbHandler.insert(m);
                            finish();
                        }
                        break;
                }
            }
        };


        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("Save");
        builder.setMessage("Are you sure");

        builder.setNeutralButton("Canael", listener);
        builder.setPositiveButton("OK", listener);

        AlertDialog dialog = builder.create();

        dialog.show();
    }

    //-----------------------------------------------------------

    class Movieditales extends AsyncTask<String, Void, String> {

        ProgressDialog dialog;

        @Override
        protected void onPreExecute() {

            dialog = new ProgressDialog(Details.this);
            dialog.setTitle("searching");
            dialog.show();

        }

        @Override
        protected String doInBackground(String... params) {
            String queryString = null;

            try {
                queryString = "" +
                        "i=" + URLEncoder.encode(params[1], "utf-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            return HttpHandler.get(params[0], queryString);
        }


        protected void onPostExecute(String s) {

            dialog.dismiss();

            Log.d(TAG, "RES  = " + s);


            if (s == null) {

                Toast.makeText(Details.this, "error getting results...", Toast.LENGTH_LONG).show();
                return;
            }


            JSONObject MovieObject = null;

            Log.d(TAG, "-----s=" + s);
            try {
                MovieObject = new JSONObject(s);
            } catch (JSONException e) {
                e.printStackTrace();
            }


            String movtitle = null;
            try {
                movtitle = MovieObject.getString("Title");
                Log.d(TAG, "titleresult=" + movtitle);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            String movposter = null;
            try {
                movposter = MovieObject.getString("Poster");
                Log.d(TAG, " movposter=" + movposter);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            String movyear = null;
            try {
                movyear = MovieObject.getString("Year");
                Log.d(TAG, " movyear=" + movyear);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            String movgenre = null;
            try {
                movgenre = MovieObject.getString("Genre");
                Log.d(TAG, "movgenre=" + movgenre);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            String movplot = null;
            try {
                movplot = MovieObject.getString("Plot");
                Log.d(TAG, "movplot=" + movplot);
            } catch (JSONException e) {
                e.printStackTrace();


                String id = null;
                try {
                    id = MovieObject.getString("imdbID");
                    Log.d(TAG, "id=" + id);
                } catch (JSONException e2) {
                    e.printStackTrace();

                    Toast.makeText(Details.this, "error parsing results...", Toast.LENGTH_LONG).show();
                }
            }

            editText.setText(movtitle);
            editText2.setText(movplot);
            editText3.setText(movgenre);
            posterurl.setText(movposter);
            theyear.setText(movyear);

            new GetImage().execute(movposter);
        }

    }
        class GetImage extends AsyncTask<String,Void,Bitmap>{

            private ProgressDialog dialog;

            @Override
            protected void onPreExecute() {
                // show progress dialog
                dialog = new ProgressDialog(Details.this);
                dialog.setMessage("please wait");
                dialog.show();
            }

            @Override
            protected Bitmap doInBackground(String... params) {

                return HttpHandler.getBitmap(params[0]);
            }

            @Override
            protected void onPostExecute(Bitmap bitmap) {

                dialog.dismiss();

                if (bitmap==null) {

                    Toast.makeText(Details.this,"error in download", Toast.LENGTH_SHORT).show();
                    posterview.setImageResource(R.mipmap.ic_launcher);
                    return;
                }

                //ok - set display the image
                posterview.setImageBitmap(bitmap);

            }

        }
    }



