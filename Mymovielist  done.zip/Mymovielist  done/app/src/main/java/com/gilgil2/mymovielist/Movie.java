package com.gilgil2.mymovielist;

import android.graphics.drawable.Drawable;

/**
 * Created by Gilly on 7/16/2015.
 */
public class Movie {

    private long id;
    private String title;
    private String plot;
    private String url;
    private String genre;
    private String year;
    //private String poster;


    public Movie(String title, String plot, String url, String genre, String year) {
        this.title = title;
        this.plot = plot;
        this.url = url;
        this.genre = genre;
        this.year = year;

        this.id = id;
    }

    public Movie(long id, String title, String plot, String url, String genre, String year) {

        this.title = title;
        this.plot = plot;
        this.url = url;
        this.genre = genre;
        this.year = year;

        this.id = id;

    }


    public String toString() {

        return title + plot + genre + url + year ;
    }


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPlot() {
        return plot;
    }

    public void setPlot(String plot) {
        this.plot = plot;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getYear() {return year;}

    public void setYear(String year) {this.year = year;}

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }


}
