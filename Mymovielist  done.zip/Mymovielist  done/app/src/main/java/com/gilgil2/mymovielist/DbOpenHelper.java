package com.gilgil2.mymovielist;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.util.Log;

/**
 * Created by Gilly on 7/18/2015.
 */
public class DbOpenHelper extends SQLiteOpenHelper {

    public static final String TAG = "DbOpenHelper";

    public static String DB_NAME = "My movie db";

    public static int DB_VERSION =5;


    public DbOpenHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.d(TAG, "creating database");

        String sql = ""
                + "CREATE TABLE " + DBconstants.TABLE_NAME_MOVIES + "("
                + DBconstants.MOVIE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + DBconstants.MOVIE_TITLE + " TEXT,"
                + DBconstants.MOVIE_PLOT + " TEXT,"
                + DBconstants.MOVIE_URL + " TEXT,"
                + DBconstants.MOVIE_GENRE + " TEXT,"
                + DBconstants.MOVIE_YEAR + " TEXT"
                + ")";
        Log.d(TAG, sql);
        db.execSQL(sql);


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        Log.d(TAG, "upgrading the database from " + oldVersion + " to " + newVersion);

        String sql = "DROP TABLE IF EXISTS " + DBconstants.TABLE_NAME_MOVIES;
        Log.d(TAG, sql);

        db.execSQL(sql);

        onCreate(db);

    }
}
